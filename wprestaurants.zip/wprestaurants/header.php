<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CHEFER - Chef Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Emblema+One&family=Poppins:wght@400;600&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

  <?php wp_head(); ?>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End -->

    <?php 
    
        $my_theme_logo_name = get_option('my_theme_logo_name');
        $theme_email = get_option('my_theme_email');
        $theme_phone = get_option('my_theme_phone');
        $theme_facebook = get_option('my_theme_facebook');
        $theme_twitter = get_option('my_theme_twitter');
        $theme_instagram = get_option('my_theme_instagram');
    
    ?>
    <!-- Header Start -->
    <div class="container-fluid bg-dark px-0">
        <div class="row gx-0 wow fadeIn" data-wow-delay="0.1s">
            <div class="col-lg-3 bg-primary d-none d-lg-block">
                <a href="index.html"
                    class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <h1 class="m-0 display-4 text-white text-uppercase"><?php echo $my_theme_logo_name; ?></h1>
                </a>
            </div>
            <div class="col-lg-9">
                <div class="row gx-0 d-none d-lg-flex bg-dark">
                    <div class="col-6 px-5 text-start">
                        <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                            <i class="fa fa-envelope text-primary me-2"></i>
                            <p class="mb-0"><?php echo $theme_email; ?></p>
                        </div>
                    </div>
                    <div class="col-6 px-5 text-end">    
                        <div class="h-100 d-inline-flex align-items-center py-2">
                            <i class="fa fa-phone-alt text-primary me-2"></i>
                            <p class="mb-0"><?php echo $theme_phone; ?></p>
                        </div>
                    </div>
                </div>
                <nav class="navbar navbar-expand-lg navbar-dark p-3 p-lg-0 px-lg-5" style="background: #111111;">
                    <a href="index.html" class="navbar-brand d-block d-lg-none">
                        <h1 class="m-0 display-4 text-primary text-uppercase">Chefer</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-bs-toggle="collapse"
                        data-bs-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    
                        <?php
                                wp_nav_menu(array(
                                    'theme_location' => 'primary_menu',
                                    'container' => false,
                                    'menu_class' => 'navbar-nav mr-auto py-0',
                                    )
                                );
                        ?>
                        <div class="d-none d-lg-flex align-items-center py-2">
                            <a class="btn btn-outline-secondary btn-square rounded-circle ms-2" href="<?php echo $theme_facebook; ?>">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a class="btn btn-outline-secondary btn-square rounded-circle ms-2" href="<?php echo $theme_twitter; ?>">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a class="btn btn-outline-secondary btn-square rounded-circle ms-2" href="<?php echo $theme_instagram; ?>">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Header End -->