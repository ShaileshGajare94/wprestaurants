 <!-- Footer Start -->
  <?php 
	$theme_footer_logo = get_option('my_theme_footer_logo');
    $theme_footer_text = get_option('my_theme_footer_text');
    $theme_footer_email = get_option('my_theme_footer_email');
    $theme_footer_phone = get_option('my_theme_footer_phone');
    $theme_footer_facebook = get_option('my_theme_footer_facebook');
    $theme_footer_twitter = get_option('my_theme_footer_twitter');
    $theme_footer_instagram = get_option('my_theme_footer_instagram');

      $form_description = get_option('form_description');
    $form_shortcode = get_option('form_shortcode');
    // Debugging output

  ?>
    <div class="container-fluid bg-dark text-secondary px-5">
        <div class="row gx-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="col-lg-8 col-md-6">
                <div class="row gx-5">
                    <div class="col-lg-4 col-md-12 pt-5 mb-5">
                        <h3 class="text-light mb-4">Get In Touch</h3>
                        <div class="d-flex mb-2">
                            <i class="bi bi-geo-alt text-primary me-2"></i>
                            <p class="mb-0"><?php echo $theme_footer_logo; ?></p>
                        </div>
                        <div class="d-flex mb-2">
                            <i class="bi bi-envelope-open text-primary me-2"></i>
                            <p class="mb-0"><?php echo $theme_footer_email; ?></p>
                        </div>
                        <div class="d-flex mb-2">
                            <i class="bi bi-telephone text-primary me-2"></i>
                            <p class="mb-0"><?php echo $theme_footer_phone; ?></p>
                        </div>
                        <div class="d-flex mt-4">
                            <a class="btn btn-primary btn-square rounded-circle me-2" href="<?php echo esc_url($theme_footer_twitter); ?>"><i
                                    class="fab fa-twitter"></i></a>
                            <a class="btn btn-primary btn-square rounded-circle me-2" href="<?php echo esc_url($theme_footer_facebook); ?>"><i
                                    class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-primary btn-square rounded-circle me-2" href="<?php echo esc_url($theme_footer_instagram); ?>"><i
                                    class="fab fa-linkedin-in"></i></a>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                        <h3 class="text-light mb-4">Quick Links</h3>
                        
                      <?php
                                wp_nav_menu(array(
                                    'theme_location' => 'quick_link',
                                    'container' => false,
                                    'menu_class' => 'd-flex flex-column justify-content-start',
                                    'walker' => new WP_Bootstrap_Navwalker(), // Use the custom walker
                            ));
                        ?>
                    </div>
                    <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                        <h3 class="text-light mb-4">More Links</h3>
                        <?php
                                wp_nav_menu(array(
                                    'theme_location' => 'more_link',
                                    'container' => false,
                                    'menu_class' => 'd-flex flex-column justify-content-start',
                                    'walker' => new WP_Bootstrap_Navwalker(), // Use the custom walker
                            ));
                        ?>
                    </div>
                               
               
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="d-flex flex-column align-items-center justify-content-center text-center h-100 p-5"
                    style="background: #111111;">
                    <h3 class="text-white mb-4">Newsletter</h3>
                    
                    <?php echo $form_description ?>
                   
                    <?php echo do_shortcode('[contact-form-7 id="86e2f55" title="Contact form 1"]'); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-4 py-lg-0 px-5" style="background: #111111;">
        <div class="row gx-5">
            <div class="col-lg-8">
                <div class="py-lg-4 text-center">
                    <p class="text-secondary mb-0">&copy; <a class="text-light fw-bold" href="#"><?php echo $theme_footer_text; ?></a>. All
                        Rights Reserved.</p>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="py-lg-4 text-center credit">
                  
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-dark py-3 fs-4 back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>


    <!-- Template Javascript -->
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/main.js"></script>
<script>
    jQuery(document).ready(function($) {
    $('#upload_logo_button').on('click', function(e) {
        e.preventDefault();

        var image = wp.media({
            title: 'Upload Logo',
            multiple: false
        }).open().on('select', function() {
            var uploaded_image = image.state().get('selection').first().toJSON();
            $('#theme_logo').val(uploaded_image.url);
        });
    });
    jQuery("#menu-main-menu a").each(function(){
        jQuery(this).addClass("nav-item nav-link");
    });
});

jQuery(window).on('load', function() {
    jQuery("#menu-main-menu a").each(function(){
        jQuery(this).addClass("nav-item nav-link");
    });
    jQuery("#menu-main-menu a:first").addClass("active");
});
    </script>
</body>
<?php wp_footer(); ?>
</html>