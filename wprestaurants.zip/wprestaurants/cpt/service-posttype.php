<?php
function create_service_post_type() {
    $labels = array(
        'name'               => 'Services',
        'singular_name'      => 'Service',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Service',
        'edit_item'          => 'Edit Service',
        'new_item'           => 'New Service',
        'view_item'          => 'View Service',
        'view_items'         => 'View Services',
        'search_items'       => 'Search Services',
        'not_found'          => 'No services found',
        'not_found_in_trash' => 'No services found in Trash',
        'all_items'          => 'All Services',
        'archives'           => 'Service Archives',
        'attributes'         => 'Service Attributes',
        'insert_into_item'   => 'Insert into service',
        'uploaded_to_this_item' => 'Uploaded to this service',
        'menu_name'          => 'Services',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_admin_bar'  => true,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-category',
        'capability_type'    => 'post',
        'supports'           => array( 'title', 'editor', 'thumbnail', 'revisions' ),
        'has_archive'        => true,
        'rewrite'            => array( 'slug' => 'services' ),
        'show_in_rest'       => true, // Enable for block editor (Gutenberg)
    );

    register_post_type( 'service', $args );

  }

add_action( 'init', 'create_service_post_type' );

/**
 * Add a meta box for the "Read More" URL in the service post type.
 *
 * This meta box allows users to enter a URL that will be used as a "Read More" link
 * for the service post type.
 */
function add_service_read_more_meta_box() {
    add_meta_box(
        'service_read_more',            // ID of the meta box
        'Read More Button URL',         // Title of the meta box
        'service_read_more_meta_box',   // Callback function to display the field
        'service',                      // Post type (custom post type 'service')
        'normal',                         // Context ('normal', 'side', or 'advanced')
        'high'                          // Priority ('default', 'low', or 'high')
    );
}

add_action( 'add_meta_boxes', 'add_service_read_more_meta_box' );

/**
 * Callback function to display the Read More URL input field in the meta box.
 *
 * @param WP_Post $post The current post object.
 */
function service_read_more_meta_box( $post ) {
    // Retrieve the current value of the custom field
    $read_more_url = get_post_meta( $post->ID, '_read_more_url', true );

    // Display the input field
    ?>
    <label for="read_more_url">Read More URL:</label>
    <input type="text" name="read_more_url" id="read_more_url" value="<?php echo esc_attr( $read_more_url ); ?>" class="widefat" />
    <?php
}


/**
 * Save the Read More URL when the service post is saved.
 *
 * @param int $post_id The ID of the post being saved.
 */

function save_service_read_more_meta( $post_id ) {
    // Check if this is a valid request
    if ( !isset( $_POST['read_more_url'] ) || !current_user_can( 'edit_post', $post_id ) ) {
        return $post_id;
    }

    // Sanitize and save the URL
    $read_more_url = sanitize_text_field( $_POST['read_more_url'] );

    // Update the post meta
    update_post_meta( $post_id, '_read_more_url', $read_more_url );
}
add_action( 'save_post', 'save_service_read_more_meta' );



