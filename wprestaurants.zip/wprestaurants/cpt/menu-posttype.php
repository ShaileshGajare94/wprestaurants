<?php
function register_menu_post_type() {
    $args = array(
        'labels' => array(
            'name'               => 'Menus',
            'singular_name'      => 'Menu',
            'add_new'            => 'Add New',
            'add_new_item'       => 'Add New Menu',
            'edit_item'          => 'Edit Menu',
            'new_item'           => 'New Menu',
            'view_item'          => 'View Menu',
            'search_items'       => 'Search Menus',
            'not_found'          => 'No menus found',
            'not_found_in_trash' => 'No menus found in Trash',
            'all_items'          => 'All Menus',
            'archives'           => 'Menu Archives',
            'attributes'         => 'Menu Attributes',
            'insert_into_item'   => 'Insert into menu',
            'uploaded_to_this_item' => 'Uploaded to this menu',
            'menu_name'          => 'Menu',
        ),
        'public'            => true,
        'has_archive'       => true,
        'show_in_rest'      => true,  // This enables Gutenberg
        'supports'          => array('title', 'editor', 'thumbnail'),
        'taxonomies'        => array('menu_category'),  // Link to taxonomy
        'rewrite'           => array('slug' => 'menu'),
        'show_in_rest'      => true,
    );
    
    register_post_type('menu', $args);
}
add_action('init', 'register_menu_post_type');

function register_menu_category_taxonomy() {
    $args = array(
        'hierarchical'      => true,
        'labels'            => array(
            'name'              => 'Menu Categories',
            'singular_name'     => 'Menu Category',
            'search_items'      => 'Search Categories',
            'all_items'         => 'All Categories',
            'parent_item'       => 'Parent Category',
            'parent_item_colon' => 'Parent Category:',
            'edit_item'         => 'Edit Category',
            'update_item'       => 'Update Category',
            'add_new_item'      => 'Add New Category',
            'new_item_name'     => 'New Category Name',
            'menu_name'         => 'Category',
        ),
        'public'            => true,
        'show_in_rest'      => true,  // Enable for Gutenberg
        'rewrite'           => array('slug' => 'menu-category'),
    );
    
    register_taxonomy('menu_category', 'menu', $args);
}
add_action('init', 'register_menu_category_taxonomy');

