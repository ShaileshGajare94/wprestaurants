<?php 
function register_teammember_post_type() {

    $labels = array(
        'name'                  => _x( 'Team Members', 'Post type general name', 'textdomain' ),
        'singular_name'         => _x( 'Team Member', 'Post type singular name', 'textdomain' ),
        'menu_name'             => _x( 'Team Members', 'Admin Menu text', 'textdomain' ),
        'name_admin_bar'        => _x( 'Team Member', 'Add New on Toolbar', 'textdomain' ),
        'add_new'               => __( 'Add New', 'textdomain' ),
        'add_new_item'          => __( 'Add New Team Member', 'textdomain' ),
        'new_item'              => __( 'New Team Member', 'textdomain' ),
        'edit_item'             => __( 'Edit Team Member', 'textdomain' ),
        'view_item'             => __( 'View Team Member', 'textdomain' ),
        'all_items'             => __( 'All Team Members', 'textdomain' ),
        'search_items'          => __( 'Search Team Members', 'textdomain' ),
        'not_found'             => __( 'No team members found.', 'textdomain' ),
        'not_found_in_trash'    => __( 'No team members found in Trash.', 'textdomain' ),
        'featured_image'        => _x( 'Team Member Photo', 'Overrides the “Featured Image” phrase', 'textdomain' ),
        'set_featured_image'    => _x( 'Set team member photo', 'textdomain' ),
        'remove_featured_image' => _x( 'Remove team member photo', 'textdomain' ),
        'use_featured_image'    => _x( 'Use as team member photo', 'textdomain' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'menu_icon'          => 'dashicons-groups', // Optional icon
        'publicly_queryable' => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'team-member' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_rest'       => true, // Enables Gutenberg/REST API
    );

    register_post_type( 'teammember', $args );
}

add_action( 'init', 'register_teammember_post_type' );


function add_teammember_meta_boxes() {
    add_meta_box(
        'teammember_social_links', // ID of the meta box
        'Social Links',            // Title of the meta box
        'display_teammember_social_links', // Callback function to display the fields
        'teammember',              // Post type where the meta box will appear
        'normal',                  // Context (normal, side, etc.)
        'high'                     // Priority (high, low, default)
    );

    add_meta_box(
        'teammember_position',     // ID of the meta box
        'Position',                // Title of the meta box
        'display_teammember_position', // Callback function to display the field
        'teammember',              // Post type where the meta box will appear
        'normal',                  // Context (normal, side, etc.)
        'high'                     // Priority (high, low, default)
    );
}

add_action( 'add_meta_boxes', 'add_teammember_meta_boxes' );

function display_teammember_social_links( $post ) {
    // Retrieve existing meta values if available
    $facebook_url = get_post_meta( $post->ID, '_facebook_url', true );
    $twitter_url = get_post_meta( $post->ID, '_twitter_url', true );
    $linkedin_url = get_post_meta( $post->ID, '_linkedin_url', true );

    wp_nonce_field( 'save_teammember_meta', 'teammember_meta_nonce' );

    ?>
    <p>
        <label for="facebook_url"><?php _e( 'Facebook URL', 'textdomain' ); ?></label>
        <input type="text" id="facebook_url" name="facebook_url" value="<?php echo esc_url( $facebook_url ); ?>" class="widefat" />
    </p>
    <p>
        <label for="twitter_url"><?php _e( 'Twitter URL', 'textdomain' ); ?></label>
        <input type="text" id="twitter_url" name="twitter_url" value="<?php echo esc_url( $twitter_url ); ?>" class="widefat" />
    </p>
    <p>
        <label for="linkedin_url"><?php _e( 'LinkedIn URL', 'textdomain' ); ?></label>
        <input type="text" id="linkedin_url" name="linkedin_url" value="<?php echo esc_url( $linkedin_url ); ?>" class="widefat" />
    </p>
    <?php
}

function display_teammember_position( $post ) {
    // Retrieve existing meta value if available
    $position = get_post_meta( $post->ID, '_position', true );

    wp_nonce_field( 'save_teammember_meta', 'teammember_meta_nonce' );

    ?>
    <p>
        <label for="position"><?php _e( 'Position', 'textdomain' ); ?></label>
        <input type="text" id="position" name="position" value="<?php echo esc_attr( $position ); ?>" class="widefat" />
    </p>
    <?php
}


function save_teammember_meta( $post_id ) {

    // Check if nonce is set and verify it
    if ( ! isset( $_POST['teammember_meta_nonce'] ) || ! wp_verify_nonce( $_POST['teammember_meta_nonce'], 'save_teammember_meta' ) ) {
        return;
    }

    // Check if the user has permission to save the data
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Save Facebook URL
    if ( isset( $_POST['facebook_url'] ) ) {
        update_post_meta( $post_id, '_facebook_url', esc_url_raw( $_POST['facebook_url'] ) );
    }

    // Save Twitter URL
    if ( isset( $_POST['twitter_url'] ) ) {
        update_post_meta( $post_id, '_twitter_url', esc_url_raw( $_POST['twitter_url'] ) );
    }

    // Save LinkedIn URL
    if ( isset( $_POST['linkedin_url'] ) ) {
        update_post_meta( $post_id, '_linkedin_url', esc_url_raw( $_POST['linkedin_url'] ) );
    }

    // Save Position
    if ( isset( $_POST['position'] ) ) {
        update_post_meta( $post_id, '_position', sanitize_text_field( $_POST['position'] ) );
    }
}

add_action( 'save_post', 'save_teammember_meta' );


