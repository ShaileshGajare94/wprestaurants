<?php   
function register_testimonials_post_type() {

    $labels = array(
        'name'                  => 'Testimonials',
        'singular_name'         => 'Testimonial',
        'menu_name'             => 'Testimonials',
        'name_admin_bar'        => 'Testimonial',
        'add_new'               => 'Add New',
        'add_new_item'          => 'Add New Testimonial',
        'new_item'              => 'New Testimonial',
        'edit_item'             => 'Edit Testimonial',
        'view_item'             => 'View Testimonial',
        'all_items'             => 'All Testimonials',
        'search_items'          => 'Search Testimonials',
        'parent_item_colon'     => 'Parent Testimonials:',
        'not_found'             => 'No testimonials found.',
        'not_found_in_trash'    => 'No testimonials found in Trash.',
    );

    $args = array(
        'labels'                => $labels,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-format-quote', // Icon for the post type
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => false,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'rewrite'               => array('slug' => 'testimonials'),
        'capability_type'       => 'post',
        'supports'              => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('testimonial', $args);
}

// Hook the custom post type registration to 'init'
add_action('init', 'register_testimonials_post_type');


// Add Meta Box for Link Position
function add_testimonial_meta_box() {
    add_meta_box(
        'testimonial_link_position', // ID for the meta box
        'Position',             // Title of the meta box
        'display_testimonial_meta_box', // Callback function that will display the meta box
        'testimonial',               // Custom Post Type slug (testimonial in our case)
        'normal',                    // Context (normal, side, advanced)
        'high'                       // Priority (high, low, default)
    );
}
add_action('add_meta_boxes', 'add_testimonial_meta_box');

// Display the content of the meta box
function display_testimonial_meta_box($post) {
    // Retrieve current value (if any)
    $link_position = get_post_meta($post->ID, '_testimonial_link_position', true);
    ?>

    <label for="testimonial_link_position">Position:</label>
    <input type="text" name="testimonial_link_position" id="testimonial_link_position" value="<?php echo esc_attr($link_position); ?>" />

    <?php
    wp_nonce_field('testimonial_link_position_nonce', 'testimonial_link_position_nonce_field'); // Nonce for security
}

// Save the custom field value when the post is saved
function save_testimonial_meta_box_data($post_id) {
    // Check if nonce is valid
    if (!isset($_POST['testimonial_link_position_nonce_field']) ||
        !wp_verify_nonce($_POST['testimonial_link_position_nonce_field'], 'testimonial_link_position_nonce')) {
        return;
    }

    // Check if it's autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // Check if user has permission to edit
    if (!current_user_can('edit_post', $post_id)) return;

    // Save or update the Link Position custom field
    if (isset($_POST['testimonial_link_position'])) {
        $link_position = sanitize_text_field($_POST['testimonial_link_position']);
        update_post_meta($post_id, '_testimonial_link_position', $link_position);
    }
}
add_action('save_post', 'save_testimonial_meta_box_data');
