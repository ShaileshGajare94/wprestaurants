<?php
function my_theme_options_page() {
    add_menu_page(
        'Theme Settings',
        'Theme Settings',
        'manage_options',
        'theme-settings',
        'my_theme_options_page_html',
        'dashicons-admin-generic',
        90
    );
}
add_action('admin_menu', 'my_theme_options_page');

// Enqueue media uploader for logo upload
function my_theme_admin_enqueue_scripts($hook) {
    if ($hook !== 'toplevel_page_theme-settings') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('my-theme-admin-js', get_template_directory_uri() . '/admin.js', ['jquery'], null, true);
}
add_action('admin_enqueue_scripts', 'my_theme_admin_enqueue_scripts');

// Display HTML for the theme options page
function my_theme_options_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'header';

    // Save form data
    if (isset($_POST['submit_theme_options'])) {
        if ($active_tab === 'header') {
            update_option('my_theme_logo_name', sanitize_text_field($_POST['my_theme_logo_name']));
            update_option('my_theme_email', sanitize_email($_POST['theme_email']));
            update_option('my_theme_phone', sanitize_text_field($_POST['theme_phone']));
            update_option('my_theme_facebook', esc_url_raw($_POST['theme_facebook']));
            update_option('my_theme_twitter', esc_url_raw($_POST['theme_twitter']));
            update_option('my_theme_instagram', esc_url_raw($_POST['theme_instagram']));
        } elseif ($active_tab === 'footer') {
            update_option('my_theme_footer_logo', sanitize_text_field($_POST['my_theme_footer_logo']));
            update_option('my_theme_footer_text', sanitize_text_field($_POST['my_theme_footer_text']));
            update_option('my_theme_footer_email', sanitize_email($_POST['my_theme_footer_email']));
            update_option('my_theme_footer_phone', sanitize_text_field($_POST['my_theme_footer_phone']));
            update_option('my_theme_footer_facebook', esc_url_raw($_POST['my_theme_footer_facebook']));
            update_option('my_theme_footer_twitter', esc_url_raw($_POST['my_theme_footer_twitter']));
            update_option('my_theme_footer_instagram', esc_url_raw($_POST['my_theme_footer_instagram']));
        } elseif ($active_tab === 'form') {
            update_option('form_description', wp_kses_post($_POST['form_description']));
            update_option('form_shortcode', wp_kses_post($_POST['form_shortcode']));
        } elseif ($active_tab === 'homepage') {
            update_option('hero_main_title', sanitize_text_field($_POST['hero_main_title']));
            update_option('hero1_content_text', sanitize_text_field($_POST['hero1_content_text']));
            update_option('hero3_content_text', sanitize_text_field($_POST['hero3_content_text']));

            // Handle image uploads for hero sections
            handle_image_upload('hero1_image');
            handle_image_upload('hero2_image');
            handle_image_upload('hero3_image');
        }elseif ($active_tab === 'about_section') {

            update_option('about_title', sanitize_text_field($_POST['about_title']));
            update_option('about_subtitle', sanitize_text_field($_POST['about_subtitle']));
            update_option('about_content', sanitize_text_field($_POST['about_content']));

            update_option('col1_title', sanitize_text_field($_POST['col1_title']));
            update_option('col1_content', sanitize_text_field($_POST['col1_content']));

             update_option('col2_title', sanitize_text_field($_POST['col2_title']));
            update_option('col2_content', sanitize_text_field($_POST['col2_content']));
           

             // Handle image uploads for hero sections
            handle_image_upload('about_image');
            handle_image_upload('col1_image');
            handle_image_upload('col2_image');

            
        }elseif ($active_tab === 'counter_section') {

            update_option('client_project1', sanitize_text_field($_POST['client_project1']));
            update_option('number_project1', sanitize_text_field($_POST['number_project1']));
            update_option('icon_class1', sanitize_text_field($_POST['icon_class1']));

            update_option('client_project2', sanitize_text_field($_POST['client_project2']));
            update_option('number_project2', sanitize_text_field($_POST['number_project2']));
            update_option('icon_class2', sanitize_text_field($_POST['icon_class2']));

            update_option('client_project3', sanitize_text_field($_POST['client_project3']));
            update_option('number_project3', sanitize_text_field($_POST['number_project3']));
            update_option('icon_class3', sanitize_text_field($_POST['icon_class3']));

            update_option('client_project4', sanitize_text_field($_POST['client_project4']));
            update_option('number_project4', sanitize_text_field($_POST['number_project4']));
            update_option('icon_class4', sanitize_text_field($_POST['icon_class4']));
        }elseif ($active_tab === 'service_section') {

            update_option('service_description', wp_kses_post($_POST['service_description']));
            update_option('service_button_name', sanitize_text_field($_POST['service_button_name']));
            update_option('service_url', esc_url_raw($_POST['service_url']));

        }elseif ($active_tab === 'menu_section') {

            update_option('menu_title', sanitize_text_field($_POST['menu_title']));
            update_option('sub_menu_title', sanitize_text_field($_POST['sub_menu_title']));

        }elseif ($active_tab === 'team_member_section') {

            update_option('team_member_title', sanitize_text_field($_POST['team_member_title']));
            update_option('team_member_subtitle', sanitize_text_field($_POST['team_member_subtitle']));

       }elseif ($active_tab === 'testimonial_section') {

            update_option('testimonial_title', sanitize_text_field($_POST['testimonial_title']));
            update_option('testimonial_subtitle', sanitize_text_field($_POST['testimonial_subtitle']));

            // Handle image uploads for testimonial background
            handle_image_upload('testimonial_bg_img');
        }
}

    // Get options
    $my_theme_logo_name = get_option('my_theme_logo_name');
    $theme_email = get_option('my_theme_email');
    $theme_phone = get_option('my_theme_phone');
    $theme_facebook = get_option('my_theme_facebook');
    $theme_twitter = get_option('my_theme_twitter');
    $theme_instagram = get_option('my_theme_instagram');
    $theme_footer_logo = get_option('my_theme_footer_logo');
    $theme_footer_text = get_option('my_theme_footer_text');
    $theme_footer_email = get_option('my_theme_footer_email');
    $theme_footer_phone = get_option('my_theme_footer_phone');
    $theme_footer_facebook = get_option('my_theme_footer_facebook');
    $theme_footer_twitter = get_option('my_theme_footer_twitter');
    $theme_footer_instagram = get_option('my_theme_footer_instagram');
    $form_description = get_option('form_description');
    $form_shortcode = get_option('form_shortcode');
    $hero_main_title = get_option('hero_main_title');
    $hero1_content_text = get_option('hero1_content_text');
    $hero3_content_text = get_option('hero3_content_text');
   

    // About Section
    $about_title = get_option('about_title');
    $about_subtitle = get_option('about_subtitle');
    $about_content = get_option('about_content');
  
    $col1_title = get_option('col1_title');
    $col1_content = get_option('col1_content');

    $col2_title = get_option('col2_title');
    $col2_content = get_option('col2_content');

    // Counter section
    $client_project1 = get_option('client_project1');
    $number_project1 = get_option('number_project1');
    $icon_class1 = get_option('icon_class1');

    $client_project2 = get_option('client_project2');
    $number_project2 = get_option('number_project2');
    $icon_class2 = get_option('icon_class2');

    $client_project3 = get_option('client_project3');
    $number_project3 = get_option('number_project3');
    $icon_class3 = get_option('icon_class3');

    $client_project4 = get_option('client_project4');
    $number_project4 = get_option('number_project4');
    $icon_class4 = get_option('icon_class4');


    $service_description = get_option('service_description');
    $service_button_name = get_option('service_button_name');
    $service_url = get_option('service_url');

    $menu_title = get_option('menu_title');
    $sub_menu_title = get_option('sub_menu_title');

    $team_member_title = get_option('team_member_title');
    $team_member_subtitle = get_option('team_member_subtitle');

    $testimonial_title = get_option('testimonial_title');
    $testimonial_subtitle = get_option('testimonial_subtitle');
    $testimonial_bg_img = get_option('testimonial_bg_img');

    ?>

    <div class="wrap">
        <h1>Theme Settings</h1>

        <h2 class="nav-tab-wrapper">
            <a href="?page=theme-settings&tab=header" class="nav-tab <?php echo $active_tab === 'header' ? 'nav-tab-active' : ''; ?>">Header</a>
            <a href="?page=theme-settings&tab=footer" class="nav-tab <?php echo $active_tab === 'footer' ? 'nav-tab-active' : ''; ?>">Footer</a>
            <a href="?page=theme-settings&tab=form" class="nav-tab <?php echo $active_tab === 'form' ? 'nav-tab-active' : ''; ?>">Form</a>
            <a href="?page=theme-settings&tab=homepage" class="nav-tab <?php echo $active_tab === 'homepage' ? 'nav-tab-active' : ''; ?>">Home Page Hero</a>
            <a href="?page=theme-settings&tab=about_section" class="nav-tab <?php echo $active_tab === 'about_section' ? 'nav-tab-active' : ''; ?>">About Section</a>
            <a href="?page=theme-settings&tab=counter_section" class="nav-tab <?php echo $active_tab === 'counter_section' ? 'nav-tab-active' : ''; ?>">Counter Section</a>
            <a href="?page=theme-settings&tab=service_section" class="nav-tab <?php echo $active_tab === 'service_section' ? 'nav-tab-active' : ''; ?>">Service Section</a>
            <a href="?page=theme-settings&tab=menu_section" class="nav-tab <?php echo $active_tab === 'menu_section' ? 'nav-tab-active' : ''; ?>">Menu Section</a>
            <a href="?page=theme-settings&tab=team_member_section" class="nav-tab <?php echo $active_tab === 'team_member_section' ? 'nav-tab-active' : ''; ?>">Team Member Section</a>
              <a href="?page=theme-settings&tab=testimonial_section" class="nav-tab <?php echo $active_tab === 'testimonial_section' ? 'nav-tab-active' : ''; ?>">Testimonial Section</a>

        </h2>

        <form method="post" action="" enctype="multipart/form-data">
            <table class="form-table">
                <?php if ($active_tab === 'header') : ?>
                    <tr><th><label for="logo_name">Logo Name</label></th><td><input type="text" id="my_theme_logo_name" name="my_theme_logo_name" value="<?php echo esc_attr($my_theme_logo_name); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_email">Email</label></th><td><input type="email" id="theme_email" name="theme_email" value="<?php echo esc_attr($theme_email); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_phone">Phone Number</label></th><td><input type="text" id="theme_phone" name="theme_phone" value="<?php echo esc_attr($theme_phone); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_facebook">Facebook URL</label></th><td><input type="url" id="theme_facebook" name="theme_facebook" value="<?php echo esc_attr($theme_facebook); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_twitter">Twitter URL</label></th><td><input type="url" id="theme_twitter" name="theme_twitter" value="<?php echo esc_attr($theme_twitter); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_instagram">LinkedIn URL</label></th><td><input type="url" id="theme_instagram" name="theme_instagram" value="<?php echo esc_attr($theme_instagram); ?>" class="regular-text" /></td></tr>
                <?php elseif ($active_tab === 'footer') : ?>
                    <tr><th><label for="theme_footer_logo">Address</label></th><td><input type="text" id="theme_footer_logo" name="my_theme_footer_logo" value="<?php echo esc_attr($theme_footer_logo); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_footer_email">Email</label></th><td><input type="email" id="theme_footer_email" name="my_theme_footer_email" value="<?php echo esc_attr($theme_footer_email); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_footer_phone">Phone</label></th><td><input type="text" id="theme_footer_phone" name="my_theme_footer_phone" value="<?php echo esc_attr($theme_footer_phone); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_footer_facebook">Facebook</label></th><td><input type="url" id="theme_footer_facebook" name="my_theme_footer_facebook" value="<?php echo esc_attr($theme_footer_facebook); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_footer_twitter">Twitter</label></th><td><input type="url" id="theme_footer_twitter" name="my_theme_footer_twitter" value="<?php echo esc_attr($theme_footer_twitter); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_footer_instagram">Instagram</label></th><td><input type="url" id="theme_footer_instagram" name="my_theme_footer_instagram" value="<?php echo esc_attr($theme_footer_instagram); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="theme_footer_text">Copyright Text</label></th><td><input type="text" id="theme_footer_text" name="my_theme_footer_text" value="<?php echo esc_attr($theme_footer_text); ?>" class="regular-text" /></td></tr>
                <?php elseif ($active_tab === 'form') : ?>
                    <tr><th><label for="form_description">Form Description</label></th><td><textarea id="form_description" name="form_description" rows="4" cols="50"><?php echo esc_textarea($form_description); ?></textarea></td></tr>
                    <tr><th><label for="form_shortcode">Form Shortcode</label></th><td><textarea id="form_shortcode" name="form_shortcode" rows="4" cols="50"><?php echo esc_textarea($form_shortcode); ?></textarea></td></tr>
                <?php elseif ($active_tab === 'homepage') : ?>
                    <tr><th><label for="hero_main_title">Main Title</label></th><td><input type="text" id="hero_main_title" name="hero_main_title" value="<?php echo esc_attr($hero_main_title); ?>" class="regular-text" /></td></tr>
                    <hr>
                    <tr><th><label for="hero1_content_text">Column 1 Content Text</label></th><td><textarea id="hero1_content_text" name="hero1_content_text" rows="4" cols="50"><?php echo esc_textarea($hero1_content_text); ?></textarea></td></tr>
                    <tr><th><label for="hero1_image">Column 1 Image</label></th><td><input type="file" id="hero1_image" name="hero1_image" class="regular-text" /></td></tr>
                    <tr><th><label for="hero2_image">Column 2 Image</label></th><td><input type="file" id="hero2_image" name="hero2_image" class="regular-text" /></td></tr>
                    <tr><th><label for="hero3_content_text">Column 3 Content Text</label></th><td><textarea id="hero3_content_text" name="hero3_content_text" rows="4" cols="50"><?php echo esc_textarea($hero3_content_text); ?></textarea></td></tr>
                    <tr><th><label for="hero3_image">Column 3 Image</label></th><td><input type="file" id="hero3_image" name="hero3_image" class="regular-text" /></td></tr>
                <?php elseif ($active_tab === 'about_section') : ?>
                    <tr><th><label for="about_title">Title</label></th><td><input type="text" id="about_title" name="about_title" value="<?php echo esc_textarea($about_title); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="about_subtitle">Sub Title</label></th><td><input type="text" id="about_subtitle" name="about_subtitle" value="<?php echo esc_textarea($about_subtitle); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="about_content">About Content</label></th><td><textarea id="about_content" name="about_content" rows="4" cols="50"><?php echo esc_textarea($about_content); ?></textarea></td></tr>
                    <tr><th><label for="about_image">About Image</label></th><td><input type="file" id="about_image" name="about_image" class="regular-text" /></td></tr>
                    <tr><th><label for="hero2_image">Column 1 Content</label></th></tr>
                     <tr><th><label for="about_image">Image</label></th><td><input type="file" id="col1_image" name="col1_image" class="regular-text" /></td></tr>
                     <tr><th><label for="about_image">Title</label></th><td><input type="text" id="col1_title" name="col1_title" value="<?php echo esc_textarea($col1_title); ?>" class="regular-text" /></td></tr>
                      <tr><th><label for="about_content">Content</label></th><td><textarea id="col1_content" name="col1_content" rows="4" cols="50"><?php echo esc_textarea($col1_content); ?></textarea></td></tr>
                   
                      <tr><th><label for="hero2_image">Column 2 Content</label></th></tr>
                     <tr><th><label for="about_image">Image</label></th><td><input type="file" id="col2_image" name="col2_image" class="regular-text" /></td></tr>
                     <tr><th><label for="about_image">Title</label></th><td><input type="text" id="col2_title" name="col2_title" value="<?php echo esc_textarea($col2_title); ?>" class="regular-text" /></td></tr>
                      <tr><th><label for="about_content">Content</label></th><td><textarea id="col2_content" name="col2_content" rows="4" cols="50"><?php echo esc_textarea($col2_content); ?></textarea></td></tr>
               
                <?php elseif ($active_tab === 'counter_section') : ?>
                    <tr><th><label for="counter">Column 1</label></th></tr>
                    <tr><th><label for="client_project">Client Project</label></th><td><input type="text" id="client_project1" name="client_project1" value="<?php echo esc_attr($client_project1); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Number Of project</label></th><td><input type="text" id="number_project1" name="number_project1" value="<?php echo esc_attr($number_project1); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Icon Class</label></th><td><input type="text" id="icon_class1" name="icon_class1" value="<?php echo esc_attr($icon_class1); ?>" class="regular-text" /></td></tr>

                    <tr><th><label for="counter">Column 2</label></th></tr>
                    <tr><th><label for="client_project">Client Project</label></th><td><input type="text" id="client_project2" name="client_project2" value="<?php echo esc_attr($client_project2); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Number Of project</label></th><td><input type="text" id="number_project2" name="number_project2" value="<?php echo esc_attr($number_project2); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Icon Class</label></th><td><input type="text" id="icon_class2" name="icon_class2" value="<?php echo esc_attr($icon_class2); ?>" class="regular-text" /></td></tr>
                    
                    <tr><th><label for="counter">Column 3</label></th></tr>
                    <tr><th><label for="client_project">Client Project</label></th><td><input type="text" id="client_project3" name="client_project3" value="<?php echo esc_attr($client_project3); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Number Of project</label></th><td><input type="text" id="number_project3" name="number_project3" value="<?php echo esc_attr($number_project3); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Icon Class</label></th><td><input type="text" id="icon_class3" name="icon_class3" value="<?php echo esc_attr($icon_class3); ?>" class="regular-text" /></td></tr>
                    
                     <tr><th><label for="counter">Column 4</label></th></tr>
                    <tr><th><label for="client_project">Client Project</label></th><td><input type="text" id="client_project4" name="client_project4" value="<?php echo esc_attr($client_project4); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Number Of project</label></th><td><input type="text" id="number_project4" name="number_project4" value="<?php echo esc_attr($number_project4); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="client_project">Icon Class</label></th><td><input type="text" id="icon_class4" name="icon_class4" value="<?php echo esc_attr($icon_class4); ?>" class="regular-text" /></td></tr>
                 <?php elseif ($active_tab === 'service_section') : ?>
                   
                   <tr><th><label for="service_description">Service Description</label></th><td><textarea id="service_description" name="service_description" class="large-text"><?php echo esc_textarea($service_description); ?></textarea></td></tr>
                   <tr><th><label for="service_icon">Service Button URL</label></th><td><input type="text" id="service_url" name="service_url" value="<?php echo esc_attr($service_url); ?>" class="regular-text" /></td></tr>
                   <tr><th><label for="service_icon">Service Button Name</label></th><td><input type="text" id="service_button_name" name="service_button_name" value="<?php echo esc_attr($service_button_name); ?>" class="regular-text" /></td></tr>
                  <?php elseif ($active_tab === 'menu_section') : ?>

                    <tr><th><label for="menu_description">Menu Title</label></th><td><textarea id="menu_title" name="menu_title" class="large-text"><?php echo esc_textarea($menu_title); ?></textarea></td></tr>
                    <tr><th><label for="menu_icon">Sub Menu Title</label></th><td><input type="text" id="sub_menu_title" name="sub_menu_title" value="<?php echo esc_attr($sub_menu_title); ?>" class="regular-text" /></td></tr>
                    <?php elseif ($active_tab === 'team_member_section') : ?>

                    <tr><th><label for="team_member_title">Team Member Title</label></th><td><input type="text" id="team_member_title" name="team_member_title" value="<?php echo esc_attr($team_member_title); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="team_member_subtitle">Team Member Subtitle</label></th><td><input type="text" id="team_member_subtitle" name="team_member_subtitle" value="<?php echo esc_attr($team_member_subtitle); ?>" class="regular-text" /></td></tr>
                    <?php elseif ($active_tab === 'testimonial_section') : ?>
                    <tr><th><label for="testimonial_title">Testimonial Title</label></th><td><input type="text" id="testimonial_title" name="testimonial_title" value="<?php echo esc_attr($testimonial_title); ?>" class="regular-text" /></td></tr>
                    <tr><th><label for="testimonial_subtitle">Testimonial Subtitle</label></th><td><input type="text" id="testimonial_subtitle" name="testimonial_subtitle" value="<?php echo esc_attr($testimonial_subtitle); ?>" class="regular-text" /></td></tr>
                     <tr><th><label for="about_image">Testimonial Background Image</label></th><td><input type="file" id="testimonial_bg_img" name="testimonial_bg_img" class="regular-text" /></td></tr>   
                    <?php endif; ?>
            </table>

            <p class="submit">
                <input type="submit" name="submit_theme_options" class="button button-primary" value="Save Changes" />
            </p>
        </form>
    </div>

    <?php
}

// Handle image upload
function handle_image_upload($image_name) {
    if (isset($_FILES[$image_name]) && $_FILES[$image_name]['error'] === UPLOAD_ERR_OK) {
        $uploaded_file = $_FILES[$image_name];
        $upload_dir = wp_upload_dir();
        $upload_path = $upload_dir['path'] . '/' . basename($uploaded_file['name']);

        if (move_uploaded_file($uploaded_file['tmp_name'], $upload_path)) {
            $image_url = $upload_dir['url'] . '/' . basename($uploaded_file['name']);
            update_option($image_name, $image_url);
        }
    } else {
        if (isset($_FILES[$image_name]) && $_FILES[$image_name]['error'] !== UPLOAD_ERR_OK) {
            echo 'There was an error uploading the image.';
        }
    }
}

class WP_Bootstrap_Navwalker extends Walker_Nav_Menu {
    function start_lvl( &$output, $depth = 0, $args = null ) {
        $output .= '<ul class="d-flex flex-column justify-content-start">';
    }

    function end_lvl( &$output, $depth = 0, $args = null ) {
        $output .= '</ul>';
    }

    function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;

        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';
        
        $id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
        $id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

        $href = ! empty( $item->url ) ? $item->url : '#';
        $output .= '<li' . $id . $class_names . '>';
        $output .= '<a class="text-secondary mb-2" href="' . esc_url( $href ) . '">';
        $output .= '<i class="bi bi-arrow-right text-primary me-2"></i>';
        $output .= apply_filters( 'the_title', $item->title, $item->ID );
        $output .= '</a>';
    }
}
?>
