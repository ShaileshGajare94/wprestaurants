<?php /* Template Name: Homepage */ 
get_header(); ?>
 <!-- Hero Start -->
  <?php
   $hero_main_title = get_option('hero_main_title');
    $hero1_content_text = get_option('hero1_content_text');
    $hero1_image = get_option('hero1_image');
     $hero2_image = get_option('hero2_image');
    $hero3_content_text = get_option('hero3_content_text');
    $hero3_image = get_option('hero3_image');
  
  
  ?>
    <div class="container-fluid p-5 mb-5 bg-dark text-secondary">
        <div class="row g-5 py-5">
            <?php if(!empty($hero_main_title)): ?>
                <div class="col-12 wow fadeIn" data-wow-delay="0.1s">
                    <h1 class="display-1 text-secondary text-center mb-0"><?php echo $hero_main_title; ?></h1>
                </div>
            <?php endif; ?>
            <div class="col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                <img class="img-fluid rounded mb-3" src="<?php echo $hero1_image; ?>">
                <p>
                    <i class="bi bi-arrow-down animate-up-down" style="font-size: 3rem;"></i>
                </p>
                <p class="mb-0">
                   <?php echo $hero1_content_text; ?>
                </p>
            </div>
            <div class="col-lg-4 wow fadeIn" data-wow-delay="0.3s" style="min-height: 500px;">
                <div class="position-relative h-100">
                    <img class="position-absolute w-100 h-100 rounded" src="<?php echo $hero2_image; ?>" style="object-fit: cover;">
                </div>
            </div>
            <div class="col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                <p>
                   <?php echo $hero3_content_text; ?>
                </p>
                <p>
                    <i class="bi bi-arrow-up animate-up-down" style="font-size: 3rem;"></i>
                </p>
                <img class="img-fluid rounded" src="<?php echo $hero3_image; ?>">
            </div>
        </div>
    </div>
    <!-- Hero End -->


    <!-- About Start -->
     <?php 
            $about_title = get_option('about_title');
            $about_subtitle = get_option('about_subtitle');
            $about_content = get_option('about_content');
            $about_image = get_option('about_image');

            $col1_title = get_option('col1_title');
            $col1_content = get_option('col1_content');

            $col2_title = get_option('col2_title');
            $col2_content = get_option('col2_content');

            $col1_image = get_option('col1_image');
            $col2_image = get_option('col2_image');
           
    ?>
    <div class="container-fluid p-5">
        <div class="row gx-5">
            <div class="col-lg-5 mb-5 mb-lg-0 wow fadeIn" data-wow-delay="0.1s" style="min-height: 500px;">
                <div class="position-relative h-100">
                    <div class="position-absolute top-0 start-0 animate-rotate"
                        style="width: 160px; height: 160px;">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/about-round.jpg" alt="">
                    </div>
                    <img class="position-absolute w-100 h-100 rounded-circle rounded-bottom rounded-end"
                        src="<?php echo $about_image; ?>" style="object-fit: cover;">
                </div>
            </div>
            <div class="col-lg-7">
                <div class="mb-4 wow fadeIn" data-wow-delay="0.2s">
                    <?php if(!empty($about_subtitle)): ?>
                    <h5 class="section-title"><?php echo $about_subtitle; ?></h5>
                    <?php endif; ?>
                    <h1 class="display-3 mb-0"><?php echo $about_title; ?></h1>
                </div>
                <p class="mb-4 wow fadeIn" data-wow-delay="0.3s"><?php echo $about_content; ?></p>
                <div class="row">
                    <div class="col-sm-6 wow fadeIn" data-wow-delay="0.4s">
                        <div class="bg-light rounded p-4">
                            <img class="img-fluid bg-primary rounded-circle mb-3" src="<?php echo $col1_image; ?>" style="width: 80px; height: 80px;">
                            <h4><?php echo $col1_title; ?></h4>
                            <p class="mb-0"><?php echo $col1_content; ?></p>
                        </div>
                    </div>
                    <div class="col-sm-6 wow fadeIn" data-wow-delay="0.5s">
                        <div class="bg-light rounded p-4">
                            <img class="img-fluid bg-primary rounded-circle mb-3" src="<?php echo $col2_image; ?>" style="width: 80px; height: 80px;">
                            <h4><?php echo $col2_title; ?></h4>
                            <p class="mb-0"><?php echo $col2_content; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <?php 
      // Counter section
    $client_project1 = get_option('client_project1');
    $number_project1 = get_option('number_project1');
    $icon_class1 = get_option('icon_class1');

    $client_project2 = get_option('client_project2');
    $number_project2 = get_option('number_project2');
    $icon_class2 = get_option('icon_class2');

    $client_project3 = get_option('client_project3');
    $number_project3 = get_option('number_project3');
    $icon_class3 = get_option('icon_class3');

    $client_project4 = get_option('client_project4');
    $number_project4 = get_option('number_project4');
    $icon_class4 = get_option('icon_class4');
    

    ?>
    <!-- Facts Start -->
    <div class="container-fluid bg-dark facts p-5 my-5">
        <div class="row gx-5 gy-4 py-5">
            <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.1s">
                <div class="d-flex">
                    <div class="rounded-circle d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px; background: #111111;">
                        <i class="<?php echo $icon_class1; ?> fs-4 text-primary"></i>
                    </div>
                    <div class="ps-4">
                        <?php if(!empty($client_project1)) { ?>
                            <h5 class="text-white"><?php echo $client_project1; ?></h5>
                        <?php } ?>
                        <h1 class="display-5 text-secondary mb-0" data-toggle="counter-up"><?php echo $number_project1; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.2s">
                <div class="d-flex">
                    <div class="rounded-circle d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px; background: #111111;">
                        <i class="<?php echo $icon_class2; ?> fs-4 text-primary"></i>
                    </div>
                    <div class="ps-4">
                        <h5 class="text-white"><?php echo $client_project2; ?></h5>
                        <h1 class="display-5 text-secondary mb-0" data-toggle="counter-up"><?php echo $number_project2; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.3s">
                <div class="d-flex">
                    <div class="rounded-circle d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px; background: #111111;">
                        <i class="<?php echo $icon_class3; ?> fs-4 text-primary"></i>
                    </div>
                    <div class="ps-4">
                        <h5 class="text-white"><?php echo $client_project3; ?></h5>
                        <h1 class="display-5 text-secondary mb-0" data-toggle="counter-up"><?php echo $number_project3; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.4s">
                <div class="d-flex">
                    <div class="rounded-circle d-flex align-items-center justify-content-center mb-3"
                        style="width: 80px; height: 80px; background: #111111;">
                        <i class="<?php echo $icon_class4; ?> fs-4 text-primary"></i>
                    </div>
                    <div class="ps-4">
                        <h5 class="text-white"><?php echo $client_project4; ?></h5>
                        <h1 class="display-5 text-secondary mb-0" data-toggle="counter-up"><?php echo $number_project4; ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->


    <!-- Feature Start -->
    <div class="container-fluid feature position-relative p-5 pb-0 mt-5">
        <div class="row g-5 gb-5">
 <?php
        $args = array(
            'post_type'      => 'service',
            'posts_per_page' => 6, // adjust how many to show
        );
        

        $services_query = new WP_Query($args);

if ($services_query->have_posts()) :
    while ($services_query->have_posts()) : $services_query->the_post();
        $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
        ?>
        <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay="0.1s">
            <div class="feature-item rounded text-center p-5">
                <?php if ($service_image): ?>
                    <img class="img-fluid bg-white rounded-circle" src="<?php echo esc_url($service_image); ?>" style="width: 150px; height: 150px;">
                <?php endif; ?>
                <h3 class="my-4"><?php the_title(); ?></h3>
                <p class="text-light"><?php echo wp_trim_words(get_the_content(), 20, '...'); ?></p>
                <a class="font-body" style="letter-spacing: 1px;" href="<?php the_permalink(); ?>">Read More <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
        <?php
    endwhile;
    wp_reset_postdata();
else :
    echo '<p>No services found.</p>';
endif;

  $service_description = get_option('service_description');
    $service_button_name = get_option('service_button_name');
    $service_url = get_option('service_url');
?>

            <div class="col-lg-12 col-md-6 text-center wow fadeIn" data-wow-delay="0.1s">
                <h1 class="display-4 text-secondary mb-4"><span class="text-primary"><?php echo $service_description; ?></span></h1>
                <a href="<?php echo esc_url($service_url); ?>" class="btn btn-primary py-3 px-5"><?php echo esc_html($service_button_name); ?></a>
            </div>
        </div>
    </div>
    <!-- Feature End -->

    <?php 
    $menu_title = get_option('menu_title');
    $sub_menu_title = get_option('sub_menu_title');

?>
    <!-- Menu Start -->
    <div class="container-fluid menu py-5 px-0">
        <div class="mb-5 text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px; margin: auto;">
            <h5 class="section-title"><?php echo $menu_title; ?></h5>
            <h1 class="display-3 mb-0"><?php echo $sub_menu_title; ?></h1>
        </div>
        <div class="tab-class text-center">
    <ul class="nav nav-pills d-inline-flex justify-content-center bg-dark text-uppercase rounded-pill mb-5 wow fadeIn" data-wow-delay="0.2s">
        <?php
        // Get all menu categories
        $terms = get_terms([
            'taxonomy' => 'menu_category',
            'orderby' => 'name',
            'order' => 'ASC',
            'hide_empty' => false,
        ]);

        if (!empty($terms) && !is_wp_error($terms)) :
            foreach ($terms as $index => $term) :
        ?>
                <li class="nav-item">
                    <a class="nav-link rounded-pill text-white <?php echo $index === 0 ? 'active' : ''; ?>" data-bs-toggle="pill" href="#tab-<?php echo $term->term_id; ?>"><?php echo esc_html($term->name); ?></a>
                </li>
        <?php
            endforeach;
        endif;
        ?>
    </ul>
    <div class="tab-content">
        <?php
        // Loop through each category and display posts in that category
        if (!empty($terms) && !is_wp_error($terms)) :
            foreach ($terms as $index => $term) :
                // Query posts for the current category
                $args = [
                    'post_type' => 'menu', 
                    'posts_per_page' => -1, // Adjust this to limit the number of posts
                    'tax_query' => [
                        [
                            'taxonomy' => 'menu_category',
                            'field' => 'term_id',
                            'terms' => $term->term_id,
                            'operator' => 'IN',
                        ],
                    ],
                ];

                $query = new WP_Query($args);
        ?>
                <div id="tab-<?php echo $term->term_id; ?>" class="tab-pane fade <?php echo $index === 0 ? 'show active' : ''; ?> p-0">
                    <div class="row g-0">
                        <?php
                        // Loop through the posts for this category
                        if ($query->have_posts()) :
                            while ($query->have_posts()) : $query->the_post();
                        ?>
                                <div class="col-lg-3 col-md-4 col-sm-6 wow fadeIn" data-wow-delay="0.1s">
                                    <div class="position-relative">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <img class="img-fluid" src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
                                        <?php endif; ?>
                                        <div class="position-absolute bottom-0 end-0 mb-4 me-4 py-1 px-3 bg-dark rounded-pill text-primary">
                                            <?php the_title(); ?>
                                        </div>
                                    </div>
                                </div>
                        <?php
                            endwhile;
                            wp_reset_postdata();
                        else :
                            echo '<p>No menu items available.</p>';
                        endif;
                        ?>
                    </div>
                </div>
        <?php
            endforeach;
        endif;
        ?>
    </div>
</div>

    </div>
    <!-- Menu End -->

   <?php 
    $team_member_title = get_option('team_member_title');
    $team_member_subtitle = get_option('team_member_subtitle');

?>
    <!-- Team Start -->
    <div class="container-fluid p-5">
        <div class="mb-5 text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px; margin: auto;">
            <h5 class="section-title"><?php echo esc_html($team_member_subtitle); ?></h5>
            <h1 class="display-3 mb-0"><?php echo esc_html($team_member_title); ?></h1>
        </div>
        <div class="row g-5">
            <?php
$args = array(
    'post_type' => 'teammember',  // Custom post type
    'posts_per_page' => -1,        // Get all team members
    'post_status' => 'publish',    // Only published posts
);

$query = new WP_Query( $args );  // Execute the custom query

if ( $query->have_posts() ) :
    while ( $query->have_posts() ) : $query->the_post(); 
        // Get custom fields
        $facebook_url = get_post_meta( get_the_ID(), '_facebook_url', true );
        $twitter_url = get_post_meta( get_the_ID(), '_twitter_url', true );
        $linkedin_url = get_post_meta( get_the_ID(), '_linkedin_url', true );
        $position = get_post_meta( get_the_ID(), '_position', true );
        $team_image = get_the_post_thumbnail_url( get_the_ID(), 'full' ); // Image for the team member
?>
        <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay="0.1s">
            <div class="team-item position-relative">
                <div class="position-relative overflow-hidden rounded-circle rounded-bottom rounded-end">
                    <img class="img-fluid w-100" src="<?php echo esc_url( $team_image ); ?>" alt="">
                    <div class="team-overlay">
                        <div class="d-flex align-items-center justify-content-start">
                            <?php if ( $twitter_url ) : ?>
                                <a class="btn btn-light btn-square rounded-circle mx-1" href="<?php echo esc_url( $twitter_url ); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                            <?php endif; ?>
                            <?php if ( $facebook_url ) : ?>
                                <a class="btn btn-light btn-square rounded-circle mx-1" href="<?php echo esc_url( $facebook_url ); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <?php endif; ?>
                            <?php if ( $linkedin_url ) : ?>
                                <a class="btn btn-light btn-square rounded-circle mx-1" href="<?php echo esc_url( $linkedin_url ); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="position-absolute start-0 bottom-0 d-flex flex-column justify-content-center w-100 rounded-bottom text-center"
                     style="height: 100px; background: rgba(34, 36, 41, .9);">
                    <h5 class="text-light"><?php the_title(); ?></h5>
                    <p class="small text-uppercase text-secondary m-0" style="letter-spacing: 3px;"><?php echo esc_html( $position ); ?></p>
                </div>
            </div>
        </div>
          <?php
    endwhile;
    wp_reset_postdata(); // Reset the global post object
else :
    echo '<p>No team members found.</p>';
endif;
?>
        </div>
    </div>
    <!-- Team End -->

   <?php 
    $testimonial_title = get_option('testimonial_title');
    $testimonial_subtitle = get_option('testimonial_subtitle');
    $testimonial_bg_img = get_option('testimonial_bg_img');
?>

    <!-- Testimonial Start -->
    <div class="container-fluid p-0 my-5">
        <div class="row g-0">
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s" style="min-height: 500px;">
                <div class="h-100 position-relative overflow-hidden" style="border-top-left-radius: 50%;">
                    <img class="position-absolute w-100 h-100" src="<?php echo esc_url($testimonial_bg_img); ?>" style="object-fit: cover;">
                </div>
            </div>
            <div class="col-lg-6 bg-dark p-5 overflow-hidden wow fadeIn" data-wow-delay="0.3s" style="border-bottom-right-radius: 50%;">
                <div class="mb-5">
                    <h5 class="section-title"><?php echo esc_html($testimonial_title); ?></h5>
                    <h1 class="display-3 text-secondary mb-0"><?php echo esc_html($testimonial_subtitle); ?></h1>
                </div>
                <div class="owl-carousel testimonial-carousel">

                  <?php
// WP Query to fetch testimonials custom post type
$args = array(
    'post_type'      => 'testimonial',       // Custom post type
    'posts_per_page' => -1,                   // Get all testimonials
    'post_status'    => 'publish',            // Only published posts
);

$testimonial_query = new WP_Query($args);

if ($testimonial_query->have_posts()) :
    while ($testimonial_query->have_posts()) : $testimonial_query->the_post();
        // Get the custom field '_testimonial_link_position'
        $testimonial_link_position = get_post_meta(get_the_ID(), '_testimonial_link_position', true);
        // Get the featured image (thumbnail)
        $testimonial_image = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail'); // You can change 'thumbnail' to other sizes if needed
        ?>
        
        <div class="testimonial-item">
            <p class="fs-4 fw-normal text-light mb-4">
                <i class="fa fa-quote-left text-primary me-3"></i>
                <?php the_content(); // Display the testimonial content ?>
            </p>
            <div class="d-flex align-items-center">
                <?php if ($testimonial_image): ?>
                    <img class="img-fluid rounded-circle" src="<?php echo esc_url($testimonial_image); ?>" alt="<?php the_title(); ?>">
                <?php else: ?>
                    <img class="img-fluid rounded-circle" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/default-testimonial.jpg" alt="<?php the_title(); ?>">
                <?php endif; ?>
                <div class="ps-4">
                    <h5 class="text-secondary"><?php the_title(); ?></h5>
                    <span class="small text-uppercase text-secondary" style="letter-spacing: 3px;">
                        <?php echo esc_html($testimonial_link_position); ?>  <!-- Profession/Position -->
                    </span>
                </div>
            </div>
        </div>

        <?php
    endwhile;
    wp_reset_postdata(); // Reset post data after the custom loop
else :
    echo '<p>No testimonials found.</p>';
endif;
?>

                   
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    <!-- Blog Start -->
    <div class="container-fluid p-5">
        <div class="mb-5 text-center wow fadeIn" data-wow-delay="0.1s" style="max-width: 700px; margin: auto;">
            <h5 class="section-title">Our Blog</h5>
            <h1 class="display-3 mb-0">Latest Articles From Food Blog</h1>
        </div>
        <div class="row g-5">
           <?php 
        // Fetch data from API
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://dummyjson.com/recipes',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        // Decode JSON response to array
        $data = json_decode($response, true);

// Check if data exists
if (!empty($data['recipes'])) :
    foreach ($data['recipes'] as $recipe) :
        // Example Date Splitting (fake date for the demo)
        $date = date('d');
        $month = date('F');
        $year = date('Y');

        // Recipe data
        $image = !empty($recipe['image']) ? $recipe['image'] : get_template_directory_uri() . '/assets/img/menu-3.jpg';
        $title = !empty($recipe['name']) ? $recipe['name'] : 'Recipe Title Here';
?>

    <div class="col-lg-4 col-md-6 wow fadeIn" data-wow-delay="0.1s">
        <div class="blog-item">
            <div class="position-relative overflow-hidden rounded-top">
                <img class="img-fluid" src="<?php echo esc_url($image); ?>" alt="">
            </div>
            <div class="bg-dark d-flex align-items-center rounded-bottom p-4">
                <div class="flex-shrink-0 text-center text-secondary border-end border-secondary pe-3 me-3">
                    <span><?php echo esc_html($date); ?></span>
                    <h6 class="text-primary text-uppercase mb-0"><?php echo esc_html($month); ?></h6>
                    <span><?php echo esc_html($year); ?></span>
                </div>
                <a class="h5 lh-base text-light" href="#"><?php echo esc_html($title); ?></a>
            </div>
        </div>
    </div>

<?php
    endforeach;
else :
    echo 'No recipes found.';
endif;
?>

          
        </div>
    </div>
    <!-- Blog End -->


    <!-- Instagram Start -->
    <div class="container-fluid position-relative instagram p-0 mt-5">
        <a href="" class="d-flex align-items-center justify-content-center position-absolute top-50 start-50 translate-middle bg-white rounded-circle" style="width: 100px; height: 100px; z-index: 1;">
            <i class="fab fa-instagram fa-2x text-secondary"></i>
        </a>
        <div class="row g-0">
            <div class="col-lg-2 col-md-3 col-sm-4 wow fadeIn" data-wow-delay="0.1s">
                <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/menu-2.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 wow fadeIn" data-wow-delay="0.2s">
                <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/menu-3.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 wow fadeIn" data-wow-delay="0.3s">
                <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/menu-4.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 wow fadeIn" data-wow-delay="0.4s">
                <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/menu-5.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 wow fadeIn" data-wow-delay="0.5s">
                <img class="img-fluid" src="img/menu-6.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 wow fadeIn" data-wow-delay="0.6s">
                <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/assets/img/menu-7.jpg" alt="">
            </div>
        </div>
    </div>
    <!-- Instagram End -->
    <?php get_footer(); ?>